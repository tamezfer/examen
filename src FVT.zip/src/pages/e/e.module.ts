import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EPage } from './e';

@NgModule({
  declarations: [
    EPage,
  ],
  imports: [
    IonicPageModule.forChild(EPage),
  ],
})
export class EPageModule {}
