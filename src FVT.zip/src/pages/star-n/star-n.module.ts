import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { StarNPage } from './star-n';

@NgModule({
  declarations: [
    StarNPage,
  ],
  imports: [
    IonicPageModule.forChild(StarNPage),
  ],
})
export class StarNPageModule {}
