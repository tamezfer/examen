import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ImagBPage } from './imag-b';

@NgModule({
  declarations: [
    ImagBPage,
  ],
  imports: [
    IonicPageModule.forChild(ImagBPage),
  ],
})
export class ImagBPageModule {}
