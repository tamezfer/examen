import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ImagMPage } from './imag-m';

@NgModule({
  declarations: [
    ImagMPage,
  ],
  imports: [
    IonicPageModule.forChild(ImagMPage),
  ],
})
export class ImagMPageModule {}
