import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NPage } from './n';

@NgModule({
  declarations: [
    NPage,
  ],
  imports: [
    IonicPageModule.forChild(NPage),
  ],
})
export class NPageModule {}
