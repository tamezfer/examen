import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { StarBPage } from './star-b';

@NgModule({
  declarations: [
    StarBPage,
  ],
  imports: [
    IonicPageModule.forChild(StarBPage),
  ],
})
export class StarBPageModule {}
