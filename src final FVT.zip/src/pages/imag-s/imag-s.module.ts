import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ImagSPage } from './imag-s';

@NgModule({
  declarations: [
    ImagSPage,
  ],
  imports: [
    IonicPageModule.forChild(ImagSPage),
  ],
})
export class ImagSPageModule {}
